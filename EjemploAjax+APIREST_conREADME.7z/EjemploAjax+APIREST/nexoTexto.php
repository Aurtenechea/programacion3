<?php 
			include("partes/texto.php");

 ?>