en Backend va el backend, que seria casi como la carpeta apirest. 	

en apirest index.php

linea 62 trae el archivo subido...ver...


funcionesABM.js

linea46
asi se sube un archivo por ajax a la api....